def hurufPalingBanyak(word):      #fungsi hurufpalingBanyak yang memiliki parameter word
    huruf = ""                    #variabel huruf yang memiliki nilai kosong
    jumlahHurufPalingBanyak = 0   #variabel yang menyimpan nilai integer 0

    for i in word:                #melakukan perulangan pada setiap word
        jumlahHuruf = len([char for char in i if char.isalpha()])   #menghitung jumlah huruf dalam sebuah kata
        if jumlahHuruf > jumlahHurufPalingBanyak:    #jika jumlahHuruf lebih besar, maka nilai jumlahHurufTerbanyak
            jumlahHurufPalingBanyak = jumlahHuruf    #akan diubah menjadi jumlahHuruf
            huruf = i
    return huruf

inp = input("Ketikkan kalimat!").split()
print("the longest word is:",hurufPalingBanyak(inp))
print("\n---L200220269---")