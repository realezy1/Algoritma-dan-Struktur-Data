#build class node and linkedlist
class Node:
    def __init__(self, data, pointer=None):
        self.data = data
        self.pointer = pointer
        
class LinkedList:
    def __init__(self):
        self.head = None
    
#tranverse the linkedlist        
    def printLinkedList(self):
        printval = self.head
        while printval is not None:
            print(printval.data)
            printval = printval.pointer
            
#insert at the beginning            
    def atBegining(self, newData):
        NewNode = Node(newData)
        NewNode.pointer = self.head
        self.head = NewNode
        
#insert at the last
    def atEnd(self, newData):
        NewNode = Node(newData)
        last = self.head
        while(last.pointer != None):
            last = last.pointer
        last.pointer = NewNode
        
#insert at the middle
    def inBetween(self, middle, newData):
        NewNode = Node(newData)
        middle = self.head
        NewNode.pointer = middle.pointer
        middle.pointer = NewNode
        
#remove item
    def RemoveNode(self, Removekey):
        HeadVal = self.head
        if (HeadVal is not None):
            if (HeadVal.data == Removekey):
                self.head = HeadVal.pointer
                HeadVal = None
                return
        while (HeadVal is not None):
            if HeadVal.data == Removekey:
                break
            prev = HeadVal
            HeadVal = HeadVal.pointer
        if (HeadVal == None):
            return
        prev.pointer = HeadVal.pointer
        HeadVal = None
    
    def traverse(self):
        current = self.head
        while current:
            yield current.data
            current = current.pointer
        
    def sum(self):
        total = 0
        for value in self.traverse():
            total += value
        return total

linked = LinkedList()
linked.atBegining(16)
linked.inBetween(linked.head.pointer, 81)
linked.atEnd(49)
linked.printLinkedList()
linked.RemoveNode(16)
linked.printLinkedList()

linked2 = LinkedList()
linked2.atBegining(7)
linked2.atBegining(9)
linked2.atBegining(6)
linked2.atBegining(2)
linked2.atBegining(5)
linked2.atBegining(3)
linked2.printLinkedList()
print(linked2.sum())
print("\n---- Oleh L200220271 ----")