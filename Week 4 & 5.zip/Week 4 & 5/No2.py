def lostNumber(array):         #fungsi yang memiliki parameter array
    jum = len(array)           #variabel jum yang menyimpan nilai panjang array
    jarak = (jum+1)*(jum+2)/2  #variabel jarak yang berisi rentang array
    total = sum(array)         #variabel total yang menyimpan nilai jumlah array
    LostNumber = jarak - total   #variabel LostNumber menyimpan nilai jarak dikurangi total
    return LostNumber            #mengembalikan nilai angka yang hilang

array = [1, 2, 3, 4, 5, 6, 8, 9, 10]
ketemu = lostNumber(array)
print("Missing number is ", ketemu)
print("\n---L200220269---")