#latihan 1.5
print("---L200220269---")
def apakahGenap(x):
    if(x%2 == 0):
        return True
    else:
        return False
    
print(apakahGenap(48))
print(apakahGenap(37))