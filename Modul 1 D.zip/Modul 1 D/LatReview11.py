#latihan 1.11
print("---L200220269---")
bil = 0
while(bil*bil < 200):
    print(bil, bil*bil)
    bil = bil + 1