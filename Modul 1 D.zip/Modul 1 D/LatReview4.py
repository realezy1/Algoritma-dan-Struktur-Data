#latihan 1.4
print("---L200220269---")
from math import sqrt as akar
def selesaikanABC(a, b, c):
    a = float(a)
    b = float(b)
    c = float(c)
    D = b**2 - 4*a*c
    x1 = (-b + akar(D))/(2*a)
    x2 = (-b - akar(D))/(2*a)
    hasil = (x1, x2)
    return hasil

k = selesaikanABC(1, -5, 6)
print(k)
print(k[0])
print(k[1])