#latihan 1.3
print("---L200220269---")
def ucapkanSalam():
    print("Assalamu 'alaikum!")

def sapa(nama):
    ucapkanSalam()
    print("Halo", nama)
    print("Selamat belajar!")

def kuadratkan(b):
    h = b*b
    return h

ucapkanSalam()
sapa("aksal")
b = kuadratkan(5)
print(b)
k = 9
print("Bilangannya", k, "kalau dipangkatkan dua jadinya", kuadratkan(k))