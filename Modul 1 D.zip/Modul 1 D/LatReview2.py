#latihan 1.2
print("---L200220269---")
print("Kita perlu bicara sebentar...")
nm = input("Siapa namamu? (ketik di sini)> ")
print("Selamat belajar", nm)
a = int("4")
kuadratnya = a*a
print(nm, ", tahukah kamu bahwa", a, "kuadratnya adalah", kuadratnya, "?")