#latihan 1.9
print("---L200220269---")
s = "Ini Budi"
for i in s:
    print(i)