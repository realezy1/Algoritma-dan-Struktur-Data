#latihan 1.1
print("---L200220269---")
a = 4
b = 5
c = a + b
print("Nilai a =", a)
print("Nilai b = ", b)
print("Sekarang, c = a + b = ", a, "+", b, "=", c)
print("")
print("Sudah Selesai.")