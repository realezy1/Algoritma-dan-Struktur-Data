#latihan 1.8
print("---L200220269---")
for i in range(0, 10):
    print(i)