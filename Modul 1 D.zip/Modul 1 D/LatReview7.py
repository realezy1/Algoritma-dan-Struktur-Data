#latihan 1.7
print("---L200220269---")
staff = {"Santi":"santi@ums.ic.id", \
         "Jokowi":"jokowi@solokab.go.id", \
         "Endang":"Endang@yahoo.com", \
         "Sulastri":"Sulastri3@gmail.com"}

yangDicari = "Santi"
if yangDicari in staff:
    print("emailnya", yangDicari, "adalah", staff[yangDicari])
else:
    print("Tidak ada yang namanya", yangDicari)