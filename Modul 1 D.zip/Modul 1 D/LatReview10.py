#latihan 1.10
print("---L200220269---")
dd = {"nama":"joko", "umur":21, "asal":"surakarta"}
for i in dd:
    print(i, "<----->", dd[i])