def jumlahHurufVokal(teks):
    huruf = len(teks)
    vokal = sum(1 for i in teks if i.lower() in "aiueo")
    return [huruf,vokal]

kalimat = input("Masukkan kalimat!")
result = jumlahHurufVokal(kalimat)
print(result[0], result[1])