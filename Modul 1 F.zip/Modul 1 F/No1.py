def cetakSiku(x):
    for i in range (1,x+1):
        print("*" * i)
cetakSiku(5)