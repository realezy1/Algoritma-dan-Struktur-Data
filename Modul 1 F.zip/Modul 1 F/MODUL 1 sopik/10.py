import math

def selesaikanABC(a, b, c):
    determinan = b**2 - 4*a*c
    if determinan < 0:
        print("Determinannya negatif. Persamaan tidak mempunyai akar real.")
        return
    else:
        akar1 = (-b + math.sqrt(determinan)) / (2*a)
        akar2 = (-b - math.sqrt(determinan)) / (2*a)
        return akar1, akar2

selesaikanABC(1, 2, 3)