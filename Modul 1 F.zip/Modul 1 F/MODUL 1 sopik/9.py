for i in range(1, 101):
    if i % 3 == 0 and i % 5 == 0:
        print('Python UMS')
    elif i % 3 == 0:
        print('Python')
    elif i % 5 == 0:
        print('UMS')
    else:
        print(i)
print("---L200220269---")