def formatRupiah(n):
    return 'Rp {:,}'.format(n).replace(',', '.')

print(formatRupiah(1500))   
print(formatRupiah(2560000))
print("---L200220269---")