def katakan(n):
    if n < 0 or n >= 1000000000:
        return "Input harus dalam rentang 0 hingga 999,999,999"

    angka = ['nol', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan', 'sembilan']

    if n < 10:
        return angka[n]
    elif n < 20:
        return "sepuluh" if n == 10 else angka[n % 10] + " belas"
    elif n < 100:
        return angka[n // 10] + " puluh " + katakan(n % 10) if n % 10 != 0 else angka[n // 10] + " puluh"
    elif n < 1000:
        return angka[n // 100] + " ratus " + katakan(n % 100) if n % 100 != 0 else angka[n // 100] + " ratus"
    elif n < 1000000:
        return katakan(n // 1000) + " ribu " + katakan(n % 1000) if n % 1000 != 0 else katakan(n // 1000) + " ribu"
    elif n < 1000000000:
        return katakan(n // 1000000) + " juta " + katakan(n % 1000000) if n % 1000000 != 0 else katakan(n // 1000000) + " juta"


print(katakan(3125750))