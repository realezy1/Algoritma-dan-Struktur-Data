def gambarlahPersegiEmpat(panjang, lebar):
    for i in range(panjang):
        if i == 0 or i == panjang - 1:
            print('@' * lebar)
        else:
            print('@' + ' ' * (lebar - 2) + '@')

# Contoh pemanggilan
gambarlahPersegiEmpat(4, 5)