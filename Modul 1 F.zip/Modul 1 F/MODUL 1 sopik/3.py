def jumlahHurufVokal(string):
    huruf_vokal = "aiueoAIUEO"
    jumlah_huruf = len(string)
    jumlah_vokal = sum(1 for huruf in string if huruf in huruf_vokal)
    return jumlah_huruf, jumlah_vokal

k = jumlahHurufVokal ('Surakarta')
print(k)  

def jumlahHurufKonsonan(string):
    huruf_vokal = 'aeiouAEIOU'
    jumlah_huruf = len(string)
    jumlah_konsonan = sum(1 for huruf in string if huruf.isalpha() and huruf not in huruf_vokal)
    return jumlah_huruf, jumlah_konsonan

k = jumlahHurufKonsonan('Surakarta')
print(k)