import random

def permainan_tebak_angka():
    # Langkah 1: Komputer membangkitkan bilangan acak antara 1 dan 100
    angka_acak = random.randint(1, 5)

    while True:
        # Langkah 2: Pengguna diminta untuk menebak angka
        tebakan = int(input("Tebak angka (antara 1 dan 100): "))

        # Langkah 3: Memeriksa apakah tebakan benar, terlalu kecil, atau terlalu besar
        if tebakan == angka_acak:
            print("Selamat! Anda berhasil menebak angka yang benar.")
            break
        elif tebakan < angka_acak:
            print("Angka terlalu kecil. Coba lagi.")
        else:
            print("Angka terlalu besar. Coba lagi.")

# Memulai permainan tebak angka
permainan_tebak_angka()