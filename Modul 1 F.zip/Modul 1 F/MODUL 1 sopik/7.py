def faktorPrima(n):
    faktor_prima = []
    div = 2
    while div <= n:
        if n % div == 0:
            faktor_prima.append(div)
            n = n // div
        else:
            div += 1
    return tuple(faktor_prima)

print(faktorPrima(10))  
print(faktorPrima(120)) 
print(faktorPrima(19))
print("---L200220269---")