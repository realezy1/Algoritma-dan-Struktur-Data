from math import sqrt as sq
def apakahPrima(n):
    n = int(n)
    assert n >= 0  
    primaKecil = [2, 3, 5, 7, 11]
    bukanPrKecil = [0, 1, 4, 6, 8, 9, 10]

    if n in primaKecil:
        return True
    elif n in bukanPrKecil:
        return False
    else:
        for i in range(2, int(sq(n))+1):
            if n % i == 0:
                return False
        return True


bilangan_input = input("Masukkan bilangan: ")

try:
    bilangan = int(bilangan_input)
    if bilangan >= 0:
        if apakahPrima(bilangan):
            print(f"{bilangan} adalah bilangan prima.")
        else:
            print(f"{bilangan} bukan bilangan prima.")
    else:
        print("Masukkan bilangan non-negatif.")
except ValueError:
    print("Masukkan bilangan bulat.")