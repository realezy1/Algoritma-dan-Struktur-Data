import math
def rerata(b):
    hasil=0
    for i in range (len (b)):
        hasil += b[i]
    return (hasil / len (b))
print('\n--- Oleh L200220235 ---')
##variance for population
def varience (x):
    n = len(x)
    mean = rerata(x)
    deviations = [(k - mean) ** 2 for k in x]
    varience = sum(deviations) / n
    return varience
#standard deviation fot pupulation
def stdev(x):
    var = varience(x)
    std_dev = math.sqrt(var)
    return std_dev

a = rerata([1,2,3,4,5])
print("Rata-rata", a)

b = varience([1,2,3,4,5])
print("Variasi", b)

c = stdev([1,2,3,4,5])
print("Satandar Deviasi", c)