class _SimpulPohonBiner(object):
    def __init__(self,data):
        self.data = data
        self.kiri = None
        self.kanan = None

A = _SimpulPohonBiner(14)
B = _SimpulPohonBiner(78)
C = _SimpulPohonBiner(2)
D = _SimpulPohonBiner(39)
E = _SimpulPohonBiner(52)
F = _SimpulPohonBiner(83)
G = _SimpulPohonBiner(41)
H = _SimpulPohonBiner(17)
I = _SimpulPohonBiner(9)
J = _SimpulPohonBiner(60)
K = _SimpulPohonBiner(23)
L = _SimpulPohonBiner(4)
M = _SimpulPohonBiner(19)

A.kiri = B
A.kanan = C
B.kiri = D
B.kanan = E
E.kiri = F
E.kanan = G
F.kiri = H
F.kanan = I
C.kiri = J
C.kanan = K
K.kiri = L
K.kanan = M

def preorderTrav(subpohon):
    if subpohon is not None:
        print(subpohon.data)
        preorderTrav(subpohon.kiri)
        preorderTrav(subpohon.kanan)

def inorderTrav(subpohon):
    if subpohon is not None:
        inorderTrav(subpohon.kiri)
        print(subpohon.data)
        inorderTrav(subpohon.kanan)

def postorderTrav(subpohon):
    if subpohon is not None:
        postorderTrav(subpohon.kiri)
        postorderTrav(subpohon.kanan)
        print(subpohon.data)

print("---Preorder---")
(preorderTrav(A))
print("---Inorder---")
(inorderTrav(A))
print("---Postorder---")
(postorderTrav(A))