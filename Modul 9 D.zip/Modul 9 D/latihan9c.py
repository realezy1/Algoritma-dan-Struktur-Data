class _SimpulPohonBiner(object):
    def __init__(self,data):
        self.data = data
        self.kiri = None
        self.kanan = None

A = _SimpulPohonBiner("Ambarawa")
B = _SimpulPohonBiner("Bantul")
C = _SimpulPohonBiner("Cimahi")
D = _SimpulPohonBiner("Denpasar")
E = _SimpulPohonBiner("Enrekang")
F = _SimpulPohonBiner("Flores")
G = _SimpulPohonBiner("Garut")
H = _SimpulPohonBiner("Halmahera Timur")
I = _SimpulPohonBiner("Indramayu")
J = _SimpulPohonBiner("Jakarta")

A.kanan = B
B.kanan = C
C.kiri = D
D.kanan = E
E.kiri = F
F.kanan = G
G.kiri = H

def preorderTrav(subpohon):
    if subpohon is not None:
        print(subpohon.data)
        preorderTrav(subpohon.kiri)
        preorderTrav(subpohon.kanan)

def inorderTrav(subpohon):
    if subpohon is not None:
        inorderTrav(subpohon.kiri)
        print(subpohon.data)
        inorderTrav(subpohon.kanan)

def postorderTrav(subpohon):
    if subpohon is not None:
        postorderTrav(subpohon.kiri)
        postorderTrav(subpohon.kanan)
        print(subpohon.data)

(preorderTrav(A))