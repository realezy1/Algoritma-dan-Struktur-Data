class Personal:
    def __init__(self, nama, umur, warnaKulit):
        self.nama = nama
        self.umur = umur
        self.warna = warnaKulit
    def __str__(self):
        string = self.nama + " berusia " + str(self.umur) + " memiliki warna kulit " + self.warna
        return string
    def dataNama(self):
        return self.nama
    def dataUmur(self):
        return self.umur
    def dataWarnaKulit(self):
        return self.warna
    
data1 = Personal("Vici", 19, "Kuning langsat")
data2 = Personal("Laila", 18, "Sawo matang")
data3 = Personal("Deni", 25, "Sawo matang")
data4 = Personal("Dewi", 22, "Putih")
data5 = Personal("Putra", 17, "Kuning langsat")
data6 = Personal("Are", 21, "Kuning langsat")
data7 = Personal("Jhonny", 23, "Putih")
data8 = Personal("Putri", 14, "Sawo matang")
data9 = Personal("Lian", 15, "Kuning langsat")
data10 = Personal("Oase", 20, "Putih")
print(data1)
print(data10)
print(data5)