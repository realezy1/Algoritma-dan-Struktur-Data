class Personal:
    def __init__(self, nama, umur, warnaKulit):
        self.nama = nama
        self.umur = umur
        self.warna = warnaKulit
    
    def __str__(self) -> str:
        string = self.nama + " berusia " + str(self.umur) + " memiliki warna kulit " + self.warna
        return string
    
    def dataNama(self):
        return self.nama
    
    def dataUmur(self):
        return self.umur
    
    def dataWarnaKulit(self):
        return self.warna
    
data1 = Personal("Vici", 19, "Kuning langsat")
data2 = Personal("Laila", 18, "Sawo matang")
data3 = Personal("Deni", 25, "Sawo matang")
data4 = Personal("Dewi", 22, "Putih")
data5 = Personal("Putra", 17, "Kuning langsat")
data6 = Personal("Are", 21, "Kuning langsat")
data7 = Personal("Jhonny", 23, "Putih")
data8 = Personal("Putri", 14, "Sawo matang")
data9 = Personal("Lian", 15, "Kuning langsat")
data10 = Personal("Oase", 20, "Putih")

def bubble(list):
    for i in range(len(list)):
        for j in range(len(list)-i-1):
            if list[j].dataUmur() > list[j+1].dataUmur():
                tmp = list[j]
                list[j] = list[j+1]
                list[j+1] = tmp
                
def selection(list):
    for i in range(len(list)):
        terkecil = i
        for j in range(i+1, len(list)):
            if list[terkecil].dataUmur() > list[j].dataUmur():
                tmp = list[terkecil]
                list[terkecil] = list[j]
                list[j] = tmp
                
def insertion(list):
    for i in range(1, len(list)):
        key = list[i]
        j = i - 1
        while j >= 0 and key.dataUmur() < list[j].dataUmur():
            list[j+1] = list[j]
            j = j-1
            list[j+1] = key

daftar = [data1, data2, data3, data4, data5, data6, data7, data8, data9, data10]
insertion(daftar)
for i in daftar:
    print(i)