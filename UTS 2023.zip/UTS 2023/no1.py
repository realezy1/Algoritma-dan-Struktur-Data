from math import sqrt as akar
def segitigaSamasisi():
    print("program menghitung luas Segitiga samasisi")
    sisi = int(input("Masukkan nilai sisi segitiga: "))
    alas = sisi/2
    tinggi = akar(sisi**2 - ((sisi/2)**2))
    luas = alas*tinggi/2
    print("Luas segitiga samasisi = alas x tinggi / 2. Maka luasnya =", luas, "satuan luas")

def belahKetupat():
    print("program menghitung luas Belah ketupat")
    d1 = int(input("Masukkan nilai diagonal 1: "))
    d2 = int(input("Masukkan nilai diagonal 2: "))
    luas = d1*d2/2
    print("Luas belah ketupat = d1 x d2 / 2. Maka luasnya =", luas, "satuan luas")
    
segitigaSamasisi()
belahKetupat()