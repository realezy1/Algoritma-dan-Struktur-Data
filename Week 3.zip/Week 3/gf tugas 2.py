class Vehicle:
    name = "motorcycle"
    color = "red"
    year_production = 2023
    capacity = "100"
    mileage = 10
    def set_capacity(self):
        return ("this is method set_capacity")
    
class Truck(Vehicle):
    pass

t = Truck()
t.name = "Truck"
t.color = "white"
t.capacity = 500
print("nama:", t.name, "\ncolor:", t.color,
      "\nyear procuction:", t.year_production,
      "\ncapacity:", t.capacity,"in kg", "\nmileage:", t.mileage)
print(t.set_capacity())
print("\n---- Oleh L200220271 ----")