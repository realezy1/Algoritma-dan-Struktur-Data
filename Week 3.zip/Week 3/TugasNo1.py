import math
class Point:
    def set_location(self, p1, p2): #Method untuk menentukan poin
        self.p1 = p1
        self.p2 = p2
    def distance(self, other): #Method untuk mengkalkulasi jarak dengan poin lainnya
        n = abs(self.p1 - other.p1)
        o = abs(self.p2 - other.p2)
        p = math.sqrt(n**2 + o**2)
        return p
    def distance_from_origin(self): #Method untuk mengkalkulasi jarak dengan poin asli/origin
        m = math.sqrt(self.p1**2 + self.p2**2)
        return m
        
poin1 = Point()
poin2 = Point()
poin1.set_location(6, 8) #Memanggil method set_location
poin2.set_location(1, 3) #Memanggil method set_location
a = poin1.distance_from_origin() #Variabel yang digunakan untuk menyimpan nilai 
                              #(nilainya berupa pemanggilan method distance_from_origin)
b = poin1.distance(poin2) #Variabel yang digunakan untuk menyimpan nilai 
                    #(nilainya berupa pemanggilan method distance)
print("Jarak dengan poin asli/origin: ", a)
print("Jarak antara poin asli/origin dengan poin lainnya: ", b)
print("\n----Oleh L200220269----")