import math
class Point:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
    def set_location(self, x, y):
        self.x = x
        self.y = y
    def distance_from_origin(self):
        a = math.sqrt(self.x**2 + self.y**2)
        return a
    def distance(self, other):
        b = abs(self.x - other.x)
        c = abs(self.y - other.y)
        d = math.sqrt(b**2 + c**2)
        return d
        
p1 = Point()
p2 = Point()
p1.set_location(6, 8)
p2.set_location(1, 3)
a = p1.distance_from_origin()
b = p1.distance(p2)
print("The distance between the origin point is", a)
print("The distance between the origin with the other point is", b)
print("\n---- Oleh L200220271 ----")