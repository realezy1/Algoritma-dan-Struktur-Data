class vehicle:
    def __init__(self,name,color,year_production,capacity,mileage ) -> None: #Membuat 5 atribut di class vehicle
        self.name = name
        self.color = color
        self.year_production = year_production
        self.capacity = capacity
        self.mileage = mileage
    def set_capacity(self): #Membuat method set_capacity di class vehicle
        return("ini adalah set capacity")

class truck(vehicle): #Class truck yang mewarisi semua atribut dan method dari class vehicle
    def __init__(self, name, color, year_production, capacity, mileage) -> None:
        super().__init__(name, color, year_production, capacity, mileage)

    def printData(self): #Untuk mencetak atribut name,color,year_production,capacity,mileage
        print("Name:",self.name,
              "\nColor:",self.color,
              "\nYear_production:",self.year_production,
              "\nCapacity:",self.capacity,
              "\nMileage:",self.mileage)

Truck = truck("Hino","Red","2004","1000Kg","50") #Variabel yang menyimpan nilai/objek atribut dari pemanggilan class truck
Truck.printData()
print("\n----L200220269----")