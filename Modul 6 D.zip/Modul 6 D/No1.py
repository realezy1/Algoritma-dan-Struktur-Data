class MhsTIF(object):
    """Class MhsTIF yang dibangun dari class Mahasiswa"""

    def __init__(self,nama,NIM,kota,us):
        """Metode inisialisasi ini menutupimetode inisiasi di class Manusia."""
        self.nama=nama
        self.NIM=NIM
        self.kotaTinggal=kota
        self.uangsaku=us

c0 = MhsTIF('Dimas', 10, 'boyolali', 280000)
c1 = MhsTIF('Said', 51, 'sragen', 250000)
c2 = MhsTIF('Aji', 2, 'surakarta', 200000)
c3 = MhsTIF('Adit', 18, 'surakarta', 245000)
c4 = MhsTIF('Eko', 4, 'boyolali', 230000)
c5 = MhsTIF('Rendy', 91, 'pedalaman', 225000)
c6 = MhsTIF('Dito', 13, 'klaten', 235000)
c7 = MhsTIF('Rafli', 5, 'sukoharjo', 215000)
c8 = MhsTIF('Yanto', 73, 'simo', 255000)
c9 = MhsTIF('Helmi', 64, 'sragen', 270000)
c10 = MhsTIF('Ali', 79, 'Karanganyar', 265000)


Daftar = [c0.NIM,c1.NIM,c2.NIM,c3.NIM,c4.NIM,c5.NIM,c6.NIM,c7.NIM,c8.NIM,c9.NIM,c10.NIM]

def mergeSort(A):
    if len(A) > 1:
        mid = len(A) // 2
        separuhKiri = A[:mid]
        separuhKanan = A[mid:]
        mergeSort(separuhKiri)
        mergeSort(separuhKanan)
        i = 0
        j = 0
        k = 0
        while i < len(separuhKiri) and j < len(separuhKanan):
            if separuhKiri[i] < separuhKanan[j]:
                A[k] = separuhKiri[i]
                i = i + 1
            else:
                A[k] = separuhKanan[j]
                j = j + 1
            k = k+1
        while i < len(separuhKiri):
            A[k] = separuhKiri[i]
            i = i + 1
            k = k + 1
        while j < len(separuhKanan):
            A[k] = separuhKanan[j]
            j = j + 1
            k = k + 1

mergeSort(Daftar)
print("Hasil Merge Sort : ",Daftar)

def quickSort(A):
    quickSortBantu(A, 0, len(A)-1)
    
def quickSortBantu(A, awal, akhir):
    if awal < akhir:
        titikBelah = partisi(A, awal, akhir)
        quickSortBantu(A, awal, titikBelah - 1)
        quickSortBantu(A, titikBelah + 1, akhir)
        
def partisi(A, awal, akhir):
    nilaiPivot = A[awal]
    penandaKiri = awal + 1
    penandaKanan = akhir
    selesai = False
    while not selesai:
        while penandaKiri <= penandaKanan and A[penandaKiri] <= nilaiPivot:
            penandaKiri = penandaKiri + 1
        while A[penandaKanan] >= nilaiPivot and penandaKanan >= penandaKiri:
            penandaKanan = penandaKanan - 1
        if penandaKanan < penandaKiri:
            selesai = True
        else:
            tmp = A[penandaKiri]
            A[penandaKiri] = A[penandaKanan]
            A[penandaKanan] = tmp
    tmp = A[awal]
    A[awal] = A[penandaKanan]
    A[penandaKanan] = tmp
    return penandaKanan

quickSort(Daftar)
print("Hasil QuickSort : ",Daftar)