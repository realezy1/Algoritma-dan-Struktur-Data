class Stack(object):
    def __init__(self):
        self.items = []
    
    def isEmpty(self):
        return len(self) == 0
    
    def __len__(self):
        return len(self.items)
    
    def peek(self):
        assert not self.isEmpty(), "Stack kosong. Tidak bisa diintip"
        return self.items[-1]
    
    def pop(self):
        assert not self.isEmpty(), "Stack kosong. Tidak bisa di-pop"
        return self.items.pop()
    
    def push(self, data):
        self.items.append(data)
        
PROMPT ="Masukkan bilangan positif (<0 untuk mengakhiri):"
myStack = Stack()
value = int(input(PROMPT))
while value >= 0:
    myStack.push(value)
    value = int(input(PROMPT))
while not myStack.isEmpty():
    value = myStack.pop()
    print(value)