from lat3 import Stack

def cetakHexa(n):
    if n == 0:
        return '0'

    hexadecimal = "0123456789ABCDEF"
    stack = Stack()
    result = ""

    while n > 0:
        rem = n % 16
        stack.push(hexadecimal[rem])
        n = n // 16

    while not stack.isEmpty():
        result += stack.pop()

    return result

print(cetakHexa(12))   
print(cetakHexa(31))  
print(cetakHexa(229))    
print(cetakHexa(255))   
print(cetakHexa(31519)) 