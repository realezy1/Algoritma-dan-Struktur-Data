from collections import deque
import heapq

class Queue:
    def __init__(self):
        self.items = deque()

    def IsEmpty(self):
        return len(self.items) == 0

    def enqueue(self, item):
        self.items.append(item)

    def dequeue(self):
        if not self.IsEmpty():
            return self.items.popleft()
        else:
            return None

    def size(self):
        return len(self.items)

    def getFrontMost(self):
        return self.items[0] if not self.IsEmpty() else None

    def getRearMost(self):
        return self.items[-1] if not self.IsEmpty() else None


class PriorityQueue:
    def __init__(self):
        self.heap = []

    def IsEmpty(self):
        return len(self.heap) == 0

    def enqueue(self, item):
        heapq.heappush(self.heap, item)

    def size(self):
        return len(self.heap)

    def getFrontMost(self):
        return self.heap[0] if not self.IsEmpty() else None

    def getRearMost(self):
        return max(self.heap) if not self.IsEmpty() else None


PQ = PriorityQueue()
PQ.enqueue(5)
PQ.enqueue(1)
PQ.enqueue(3)
print(PQ.getFrontMost()) 
print(PQ.getRearMost())   


Q = Queue()
Q.enqueue(1)
Q.enqueue(2)
Q.enqueue(3)
print(Q.getFrontMost()) 
print(Q.getRearMost()) 