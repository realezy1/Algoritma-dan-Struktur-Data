return max(self.heap) if not self.IsEmpty() else None
