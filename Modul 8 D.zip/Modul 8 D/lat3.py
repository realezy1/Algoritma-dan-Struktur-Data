class Stack(object):
    def __init__(self):
        self.items = []
    
    def isEmpty(self):
        return len(self) == 0
    
    def __len__(self):
        return len(self.items)
    
    def peek(self):
        assert not self.isEmpty(), "Stack kosong. Tidak bisa diintip"
        return self.items[-1]
    
    def pop(self):
        assert not self.isEmpty(), "Stack kosong. Tidak bisa di-pop"
        return self.items.pop()
    
    def push(self, data):
        self.items.append(data)
        
class StackLL(object):
    def __init__(self):
        self.top = None
        self.size = 0
        
    def isEmpty(self):
        return self.top is None
    
    def __len__(self):
        return self.size
    
    def peek(self):
        assert not self.isEmpty(), "Tidak bisa diintip. Stack kosong."
        return self.top.items
    
    def pop(self):
        assert not self.isEmpty(), "Tidak bisa pop dari stack kosong."
        node = self.top
        self.top = self.top.next
        self.size -= 1
        return node.items
    
    def push(self, data):
        self.top = _stackNode(data, self.top)
        self.size += 1
        
class _stackNode(object):
    def __init__(self, data, link):
        self.items = data
        self.next = link
        
def cetakBiner(d):
    f = Stack()
    if d == 0: f.push(0);
    while d != 0:
        sisa = d%2
        d = d//2
        f.push(sisa)
    st = ""
    for i in range(len(f)):
        st = st + str(f.pop())
    return st
print(cetakBiner(11))
print(cetakBiner(53))