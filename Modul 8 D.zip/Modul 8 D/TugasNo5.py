import heapq

class PriorityQueue:
    def __init__(self):
        self.heap = []

    def IsEmpty(self):
        return len(self.heap) == 0

    def enqueue(self, item):
        heapq.heappush(self.heap, item)

    def dequeue(self):
        return heapq.heappop(self.heap) if not self.IsEmpty() else None

    def size(self):
        return len(self.heap)

    def getFrontMost(self):
        return self.heap[0] if not self.IsEmpty() else None

    def getRearMost(self):
        return max(self.heap) if not self.IsEmpty() else None

PQ = PriorityQueue()
PQ.enqueue(5)
PQ.enqueue(1)
PQ.enqueue(3)
print(PQ.getFrontMost())
print(PQ.getRearMost())
PQ.dequeue()