class StackLL(object):
    def __init__(self):
        self.top = None
        self.size = 0
        
    def isEmpty(self):
        return self.top is None
    
    def __len__(self):
        return self.size
    
    def peek(self):
        assert not self.isEmpty(), "Tidak bisa diintip. Stack kosong."
        return self.top.items
    
    def pop(self):
        assert not self.isEmpty(), "Tidak bisa pop dari stack kosong."
        node = self.top
        self.top = self.top.next
        self.size -= 1
        return node.items
    
    def push(self, data):
        self.top = _stackNode(data, self.top)
        self.size += 1
        
class _stackNode(object):
    def __init__(self, data, link):
        self.items = data
        self.next = link
        
PROMPT ="Masukkan bilangan positif (<0 untuk mengakhiri):"
myStack = StackLL()
value = int(input(PROMPT))
while value >= 0:
    myStack.push(value)
    value = int(input(PROMPT))
while not myStack.isEmpty():
    value = myStack.pop()
    print(value)