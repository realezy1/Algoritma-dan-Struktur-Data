class PriorityQueue(object):
    def __init__(self):
        self.qlist = []
        
    def __len__(self):
        return len(self.qlist)
    
    def isEmpty(self):
        return len(self) == 0
    
    def enqueue(self, data, priority):
        entry = _PriorityQEntry(data, priority)
        self.qlist.append(entry.all)
        
    def dequeue(self):
        pass
    
class _PriorityQEntry(object):
    def __init__(self, data, priority):
        self.items = data
        self.priority = priority
        self.all = (data,priority)

S = PriorityQueue()
S.enqueue("Jeruk",4)
S.enqueue("Tomat",2)
S.enqueue("Mangga",0)
S.enqueue("Duku",5)
S.enqueue("Pepaya",2)
print(S.qlist)
S.dequeue()
S.dequeue()
S.dequeue()