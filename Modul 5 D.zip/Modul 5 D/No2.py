def mengabungkanArray(arr1, arr2):
    arrayBaru = []
    i = j = 0
    
    while i < len(arr1) and j < len(arr2):
        if arr1[i] < arr2[j]:
            arrayBaru.append(arr1[i])
            i += 1
        else:
            arrayBaru.append(arr2[j])
            j += 1
    
    while i < len(arr1):
        arrayBaru.append(arr1[i])
        i += 1
    
    while j < len(arr2):
        arrayBaru.append(arr2[j])
        j += 1
    
    return arrayBaru

# Contoh penggunaan:
A = [1, 5, 7, 9, 21, 55, 99]
B = [4, 8, 10, 90, 95]
C = mengabungkanArray(A, B)
print("Array C:", C)