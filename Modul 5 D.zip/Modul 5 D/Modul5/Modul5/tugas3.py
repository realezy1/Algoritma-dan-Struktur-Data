from time import time as detak
from random import shuffle as kocok

k = list(range(1,6001))
kocok(k)
u_bub = k[:]
u_sel = k[:]
u_ins = k[:]

def swap(array, i, j):
    tmp = array[i]
    array[i] = array[j]
    array[j] = tmp
    
def cariPosisiYangTerkecil(array, dariSini, sampaiSini):
    posisiYangTerkecil = dariSini
    for i in range(dariSini+1, sampaiSini):
        if array[i] < array[posisiYangTerkecil]:
            posisiYangTerkecil = i
    return posisiYangTerkecil

def bubbleSort(array):
    n = len(array)
    for i in range(n):
        for j in range(0, n-i-1):
            if array[j] > array[j+1]:
                swap(array, j, j+1)
                
def selectionSort(array):
    n = len(array)
    for i in range(n):
        indexKecil = cariPosisiYangTerkecil(array, i, n)
        if indexKecil != i:
            swap(array, i, indexKecil)
            
def insertionSort(array):
    n = len(array)
    for i in range(1, n):
        nilai = array[i]
        j = i
        while j > 0 and nilai < array[j - 1]:
            array[j] = array[j - 1]
            j -= 1
        array[j] = nilai

aw = detak()
bubbleSort(u_bub)
ak = detak()
print('bublble: %g detik' %(ak-aw))
aw = detak()
selectionSort(u_sel)
ak = detak()
print('selection: %g detik' %(ak-aw))
aw = detak()
insertionSort(u_ins)
ak = detak()
print('insertion: %g detik' %(ak-aw))
