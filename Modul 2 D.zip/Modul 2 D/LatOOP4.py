import LatOOP3
class Mahasiswa(LatOOP3.Manusia):
    listKuliah = []
    def __init__(self, nama, NIM, kota, us):
        "Metode inisiasi ini menutupi metode inisiasi di class Manusia."
        self.nama = nama
        self.NIM = NIM
        self.kotaTinggal = kota
        self.UangSaku = us
    def __str__(self):
        s = self.nama + ", NIM " + str(self.NIM) \
            + ", Tinggal di " + str(self.kotaTinggal) \
            + ", Uang saku Rp." + str(self.UangSaku) \
            + " tiap bulannya."
        return s
    def ambilNama(self):
        return self.nama
    def ambilNIM(self):
        return self.NIM
    def ambilUangSaku(self):
        return self.UangSaku
    def makan(self, s):
        """Metode ini menutupi metode "makan"-nya class Manusia.
        Mahasiswa kalau makan sambil belajar."""
        print("Saya baru saja makan", s, "sambil belajar")
        self.keadaan = "kenyang"
    def ambilKotaTinggal(self):
        return self.kotaTinggal
    def perbaruiKotaTinggal(self, kotaTinggalBaru):
        self.kotaTinggal = kotaTinggalBaru
    def tambahUangSaku(self, uangSakuTambahan):
        self.UangSaku = self.UangSaku + uangSakuTambahan
    def ambilKuliah(self, mataKuliah):
        self.listKuliah.append(mataKuliah)
        return self.listKuliah
    def hapusKuliah(self, mataKuliah):
        self.listKuliah.remove(mataKuliah)
        return self.listKuliah

        
Nama = input("Masukkan Nama! ")
Nim = input("Masukkan NIM! ")
Kota = input("Masukkan kota tinggal! ")
Saku = input("Masukkan uang saku! ")
m234 = Mahasiswa(Nama, Nim, Kota, Saku)
print(m234)
print("\n---L200220269---")
print(m234.listKuliah)
m234.ambilKuliah("Matematika Diskrit")
print(m234.listKuliah)
m234.ambilKuliah("Algoritma dan Struktur Data")
print(m234.listKuliah)
m234.hapusKuliah("Matematika Diskrit")
print(m234.listKuliah)
print("\n---L200220269---")

m1 = Mahasiswa("Jamil", 234, "Surakarta", 250000)
m2 = Mahasiswa("Andi", 365, "Magelang", 275000)
m3 = Mahasiswa("Sri", 676, "Yogyakarta", 240000)
print(m1.ambilNama())
print(m2.ambilNIM())
m3.ucapkanSalam()
print(m3.keadaan)
m3.makan("gado-gado")
print(m3.keadaan)
print(m3)

m7 = Mahasiswa("Putri", 234, "Jakarta", 350000)
m9 = Mahasiswa("Budi", 123, "Surabaya", 270000)
print(m9.ambilKotaTinggal())
m9.perbaruiKotaTinggal("Sleman")
print(m9.ambilKotaTinggal())
print(m7.ambilUangSaku())
m7.tambahUangSaku(50000)
print(m7.ambilUangSaku())
print("\n---L200220269---")
