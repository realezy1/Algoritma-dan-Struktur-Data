import LatOOP3
class Mahasiswa(LatOOP3.Manusia):
    def __init__(self, nama, NIM, kota, us):
        "Metode inisiasi ini menutupi metode inisiasi di class Manusia."
        self.nama = nama
        self.NIM = NIM
        self.kotaTinggal = kota
        self.UangSaku = us
    def __str__(self):
        s = self.nama + ", NIM " + str(self.NIM) \
            + ", Tinggal di " + str(self.kotaTinggal) \
            + ", Uang saku Rp." + str(self.UangSaku) \
            + " tiap bulannya."
        return s
    def ambilNama(self):
        return self.nama
    def ambilNIM(self):
        return self.NIM
    def ambilUangSaku(self):
        return self.UangSaku
    def makan(self, s):
        """Metode ini menutupi metode "makan"-nya class Manusia.
        Mahasiswa kalau makan sambil belajar."""
        print("Saya baru saja makan", s, "sambil belajar")
        self.keadaan = "kenyang"
        
m1 = Mahasiswa("Jamil", 234, "Surakarta", 250000)
m2 = Mahasiswa("Andi", 365, "Magelang", 275000)
m3 = Mahasiswa("Sri", 676, "Yogyakarta", 240000)
print(m1.ambilNama())
print(m2.ambilNIM())
m3.ucapkanSalam()
print(m3.keadaan)
m3.makan("gado-gado")
print(m3.keadaan)
print(m3)

daftar = [m1, m2, m3]
for i in daftar:
    print(i)
    
print(daftar[2].ambilNama())