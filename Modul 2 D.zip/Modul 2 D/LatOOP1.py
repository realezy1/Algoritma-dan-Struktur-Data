import ModulPythonPertamaku
ModulPythonPertamaku.ucapkanSalam()
ModulPythonPertamaku.kuadratkan(5)