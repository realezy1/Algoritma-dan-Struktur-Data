import LatOOP3
class SiswaSMA(LatOOP3.Manusia):
    def __init__(self, nama, kelas, noAbsen):
        self.nama = nama
        self.kelas = kelas
        self.noAbsen = noAbsen
    def __str__(self) -> str:
        student = self.nama + "\nKelas: " + str(self.kelas) \
            + "\nNomor Absen: " + str(self.noAbsen)
        return student

s1 = SiswaSMA("Jay","MIPA 2",5)
print(s1)
print("\n---L200220269---")