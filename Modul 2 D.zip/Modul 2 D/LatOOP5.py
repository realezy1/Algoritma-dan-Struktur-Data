import LatOOP4
class MhsTIF(LatOOP4.Mahasiswa):
    """Class MhsTIF yang dibangun dari class Mahasiswa"""
    def katakanPy(self):
        print("Python is cool.")
        
m4 = MhsTIF("Badu", 334, "Sragen", 230000)
print(m4)
print(m4.katakanPy()) #fungsi dari class MhsTIF
print(m4.keadaan) #atribut yg berasal dari class Manusia
m4.makan("Pecel")
print(m4.keadaan) #atribut yg berasal dari class Manusia
m4.ucapkanSalam() #fungsi yg berasal dari class Manusia
print(m4.ambilNIM()) #fungsi dari class Mahasiswa
print("\n---L200220269---")