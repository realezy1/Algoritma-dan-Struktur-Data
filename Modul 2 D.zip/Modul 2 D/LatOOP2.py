class Pesan(object):
    """
        Sebuah class bernama Pesan.
        untuk memahami konsep Class dan Object.
    """
    def __init__(self, sebuahString):
        self.teks = sebuahString
    def cetakIni(self):
        print(self.teks)
    def cetakPakaiHurufKapital(self):
        print(str.upper(self.teks))
    def cetakPakaiHurufKecil(self):
        print(str.lower(self.teks))
    def jumKar(self):
        return len(self.teks)
    def cetakJumlahKarakter(self):
        print("Kalimatku mempunyai", len(self.teks), "karakter")    
    def perbarui(self, stringBaru):
        self.teks = stringBaru
    def apakahTerkandung(self, string):
        return string in self.teks
    def hitungKonsonan(self):
        hurufVokal = "aiueoAIUEO"
        hurufKonsonan = 0
        for i in self.teks:
            if i.lower() not in hurufVokal:
                hurufKonsonan += 1
        return hurufKonsonan
    def hitungVokal(self):
        hurufVokal = "aiueoAIUEO"
        jumlahVokal = sum(1 for char in self.teks if char in hurufVokal)
        return jumlahVokal
        
pesanA = Pesan("Aku suka kuliah ini")
pesanB = Pesan("Surakarta: the Spirit of Java")
p9 = Pesan("Indonesia adalah negeri yang indah")
p10 = Pesan("Surakarta")

pesanA.cetakIni()
pesanA.cetakJumlahKarakter()
pesanB.cetakJumlahKarakter()
pesanA.cetakPakaiHurufKapital()
pesanA.cetakPakaiHurufKecil()
pesanA.perbarui("Aku senang struktur data")
pesanA.cetakIni()
print(p9.apakahTerkandung("ege"))
print(p9.apakahTerkandung("eka"))
print(p10.hitungKonsonan())
print(p10.hitungVokal())
print("\n---L200220269---")