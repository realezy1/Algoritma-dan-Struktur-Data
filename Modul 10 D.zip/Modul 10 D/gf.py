class MyGirlFriend:
    def __init__(self, name, age, birthday, herBfName, personality) -> None:
        self.name = name
        self.age = age
        self.birthday = birthday
        self.herBfName = herBfName
        self.personality = personality

    def __str__(self) -> str:
        return (
            f"My girlfriend's name is {self.name}. She will be {self.age} years old on {self.birthday}. "
            f"She has a handsome boyfriend and his name is {self.herBfName}. "
            f"I really love her personality because she's like {self.personality} when she is with me. "
            "I love you, sayang. I really mean it."
        )

gf = MyGirlFriend("Vici Oase", 19, "7 August 2024", "Aksal", "a 7 years old child")
print(gf)

def ily(message):
    if message.lower() == "i love you":
        print("She will be very happy.")
    else:
        print("She will be mad.")

me = input("What will you say to her? ")
ily(me)