import timeit;

def jumlah_cara_1(n):
    hasilnya = 0;
    for i in range(1, n + 1):
        hasilnya += i;
    return hasilnya;

def jumlahkan_cara_2(n):
    return (n * (n + 1)) // 2;

# Variable the setup code for timeit
siap1 = """
from __main__ import jumlah_cara_1
""";

siap2 = """
from __main__ import jumlahkan_cara_2
""";

# Variable the statements to be timed
cara_1_10k = "jumlah_cara_1(10000)";
cara_1_1m = "jumlah_cara_1(1000000)";
cara_2_10k = "jumlahkan_cara_2(10000)";
cara_2_1m = "jumlahkan_cara_2(1000000)";

# Time the execution
for i in range(5):
    time_1_10k = timeit.timeit(cara_1_10k, setup=siap1, number=1);
    time_1_1m = timeit.timeit(cara_1_1m, setup=siap1, number=1);
    print(f"Jumlah cara 1 untuk 10000 memerlukan {time_1_10k:.8f} detik");
    print(f"Jumlah cara 1 untuk 1000000 memerlukan {time_1_1m:.8f} detik");

print("---------------------------------------------------");

for i in range(5):   
    time_2_10k = timeit.timeit(cara_2_10k, setup=siap2, number=1);
    time_2_1m = timeit.timeit(cara_2_1m, setup=siap2, number=1);
    print(f"Jumlah cara 2 untuk 10000 memerlukan {time_2_10k:.8f} detik");
    print(f"Jumlah cara 2 untuk 1000000 memerlukan {time_2_1m:.8f} detik");
