from timeit import timeit

def jumlahkan_cara_1(n):
    hasilnya = 0
    for i in range(1, n+1):
        hasilnya = hasilnya + i
    return hasilnya

# Membuat fungsi wrapper untuk memanggil dengan argumen
def call_jumlahkan_cara_1(n):
    return lambda: jumlahkan_cara_1(n)

#Untuk mencetak nilai dari fungsi jumlahkan_cara_1 yang menggunakan timeit
print("---A---")
print(timeit(call_jumlahkan_cara_1(10), number=10))
print(timeit(call_jumlahkan_cara_1(100), number=100))

def jumlahkan_cara_2(n):
    return (n * (n + 1)) / 2

#Membuat fungsi wrapper untuk memanggil dengan argumen
def call_jumlahkan_cara_2(n):
    return lambda: jumlahkan_cara_2(n)

#Untuk mencetak nilai dari fungsi jumlahkan_cara_2 yang menggunakan timeit
print("---B---")
print(timeit(call_jumlahkan_cara_2(100), number=10))
print(timeit(call_jumlahkan_cara_2(100), number=100))