from timeit import timeit

#Fungsi sortList
def sortList():
    g = [1, 4, 6, 2, 8, 7, 3]
    g.sort()

execTime1 = timeit(sortList, number=10)
print("Execute time of sortList(): ", execTime1)

#Fungsi SortedList
def sortedList():
    g = [9, 8, 7, 6, 4]
    sorted(g)

execTime2 = timeit(sortedList, number=10)
print("Execute time of sortedList(): ", execTime2)