import timeit;
import matplotlib.pyplot as plt;

def insert_time(n):
    setup_code = f"a = list(range({n}))";
    time = timeit.timeit(f"a.insert(0, -1)", setup=setup_code, number=1000);
    return time / 1000;

nilai_n = list(range(1, 10001, 100));

times = [insert_time(n) for n in nilai_n];

plt.plot(nilai_n, times);
plt.xlabel("Jumlah elemen (n)");
plt.ylabel("Waktu rata rata (s)");
plt.title("Mengkonfirmasi waktu metode insert() pada list");
plt.grid(True);
plt.show();