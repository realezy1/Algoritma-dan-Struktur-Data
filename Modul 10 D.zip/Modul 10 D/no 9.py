import timeit;
import matplotlib.pyplot as plt;
import random;

def measure_in_time(n):
    setup_code = f"a = []";
    time = timeit.timeit(f"{n+1} in a", setup=setup_code, number=1000);
    return time / 10000;

nilai_n = list(range(1, 10001, 100));

times = [measure_in_time(n) for n in nilai_n];

plt.plot(nilai_n, times);
plt.xlabel("Jumlah elemen (n)");
plt.ylabel("Waktu rata rata (s)");
plt.title("Mengkonfirmasi waktu operasi dengan 'in' pada list");
plt.grid(True);
plt.show();