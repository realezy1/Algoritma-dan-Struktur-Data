import sys
import random
import timeit

sys.path.insert(1, "D:\\Praktikum Algoritma Struktur Data 2024\\Modul 5")
from insertion import insertionSort

# Define setup code to import insertionSort and create lists
setup_code = """
from __main__ import insertionSort
import random
"""

# Define the statements to create shuffled, reversed, and sorted lists
stmt_shuffle = """
L = list(range(3000))
random.shuffle(L)
insertionSort(L)
"""

stmt_reverse = """
L = list(range(3000))
L = L[::-1]
insertionSort(L)
"""

stmt_sorted = """
L = list(range(3000))
insertionSort(L)
"""

# Time the execution
for i in range(5):
    time_shuffle = timeit.timeit(stmt_shuffle, setup=setup_code, number=1)
    print(f"Mengurutkan 3000 bilangan (acak), memerlukan {time_shuffle:.7f} detik")
    
print("----------------------------------------------------")

for i in range(5):
    time_reverse = timeit.timeit(stmt_reverse, setup=setup_code, number=1)
    print(f"Mengurutkan 3000 bilangan (terbalik), memerlukan {time_reverse:.7f} detik")
    
print("----------------------------------------------------")

for i in range(5):
    time_sorted = timeit.timeit(stmt_sorted, setup=setup_code, number=1)
    print(f"Mengurutkan 3000 bilangan (terurut), memerlukan {time_sorted:.7f} detik")
    
print("----------------------------------------------------")
