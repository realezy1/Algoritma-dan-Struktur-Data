import timeit;
import random;

#Fungsi yang digunakan untuk mengset-up waktu yang dibutuhkan dalam best case,avg case, dan case terburuk
def sorted_performance(data):
    setup_code = f"data = {data}";
    time = timeit.timeit('sorted(data)', setup=setup_code, number=100);
    return time/100;

#Untuk mengetahui best time 
data_sorted = list(range(1000));
best_case = sorted_performance(data_sorted);
print(f"Waktu Terbaik : {best_case:.7f} detik");

#Untuk mengetahui average list random
time_average = sorted_performance(random.sample(range(1000), 1000));
print(f"Rata rata waktu : {time_average:.7f} detik");

#Untuk mengetahui reverse 
reverse_time = sorted_performance(list(range(1000, 0, -1)));
print(f"Waktu Terbalik : {reverse_time:.7f} detik");