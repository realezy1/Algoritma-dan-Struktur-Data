import re

cocok = re.findall(r'te+','ghdteeeh')
print(cocok)
cocok = re.findall(r'e+','teeheeee')
print(cocok)

polanya = r'\d\s*\d\s*\d'
cocok = re.findall(polanya,'xx1 2   3xx')
print(cocok)
cocok = re.findall(polanya,'xx12  3xx')
print(cocok)
cocok = re.findall(polanya,'xx123xx')
print(cocok)

cocok = re.findall(r'^k\w+','mejakursi')
print(cocok)
cocok = re.findall(r'k[\w\s]+','mejakursi tamu saya')
print(cocok)

s = "Alamatku adalah dita-b@google.com mas"
cocok = re.findall(r'\w+@\w+',s)
print(cocok[0])
cocok = re.findall(r'[\w.-]+@[\w.-]+',s)
print(cocok)