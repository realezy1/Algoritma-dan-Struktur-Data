import re

cocok = re.findall(r"eee","teeeh")
print(cocok)
cocok = re.findall(r"ehs","teeeh")
print(cocok)
cocok = re.findall(r"..h","teeeh")
print(cocok)
cocok = re.findall(r"\d\d\d","t123h di 2019 bulan 02")
print(cocok)
cocok = re.findall(r"\w\w\w","@@a*bc#def*tghh!!")
print(cocok)