import re

file = open('KEI.html', 'r', encoding='latin1')
text = file.read()
pola = r'title="([^"]+)">[^<]+</a></td>\s*<td>([\d.]+)</td>\s*<td>([\d.]+)</td>\s*<td>([\d.]+)</td>\s*<td>([\d.]+)</td>'
matches = re.findall(pola, text)
hasil = [(match[0], float(match[4])) for match in matches]
print(hasil)