import re

s = "Alamatku adalah dita-b@google.com mas"
cocok = re.findall(r'([\w.-]+)@([\w.-]+)',s)
print(cocok[0][0])
print(cocok[0][1])

s = 'Alamatku sri@google.com serta joko@abc.com ok bro. atau don@email.com'
pola = r'[\w\.-]+@[\w\.-]+'
e = re.findall(pola,s)
print(e)

pola = r'([\w\.-]+)@([\w\.-]+)'
e = re.findall(pola,s)
print(e)
for tup in e:
    print('user',tup[0],'dengan host:',tup[1])

f = open('test.txt','r',encoding='latin1')
teks = f.read()
f.close()
p = r'sebuah pola'
strings = re.findall(p,teks)