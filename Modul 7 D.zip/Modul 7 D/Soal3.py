import re

file = open('Indonesia.txt','r',encoding='utf-8')
text = file.read()
pola = r'di \w+'
kata = re.findall(pola,text)
print(kata)