import re

file = open('Indonesia.txt','r',encoding='utf-8')
text = file.read()
kata = re.findall(r'di\w+',text)
print(kata)