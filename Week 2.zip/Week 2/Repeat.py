def hapus(inp):  #Fungsi hapus yang memiliki parameter inp
    list = []    #Variabel yang memiliki nilai list kosong
    #Terdapat perulangan angka pada inp dan dilakukan pengondisian jika angka tidak di dalam list, maka
    #angka dimasukkan ke dalam list
    for angka in inp :
        if angka not in list:
            list.append(angka)
    return list

#Meminta inputan pada user
inp_angka = input("Masukkan angka dengan spasi!")
inp = [int(num) for num in inp_angka.split()]

#Menampilkan output
hasil = hapus(inp)
print("Menampilkan list setelah mengeliminasi repeat number", hasil)
print("\n----L200220269----")