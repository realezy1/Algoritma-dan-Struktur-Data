def sum(num): #Fungsi sum yang memiliki parameter num
    if num == 1 or num == 0: #Blok kondisional jika parameter num sama dengan 1 atau sama dengan 0,
        return 1            # maka mengembalikan nilai 1
    elif num < 0:
        return ("Negative number") #Jika num kurang dari 0, maka mencetak teks Negative number
    else:        
        return num + sum(num-1) 
    """Blok kondisional jika parameter num tidak sama dengan 1, maka mengembalikan parameter
        num ditambah dengan fungsi sum yang memiliki parameter num dikurangi 1"""

input = int(input("Masukkan angka:")) #Membuat variabel input masukkan angka
print("Hasil penjumlahan =", sum(input)) #Mencetak hasil output dari fungsi sum
print("\n----- Oleh L200220269 -----")