Angka = int(input("Masukkan angka:")) #Varibel angka yang meminta input angka dari user
AngkaPrima = "ini adalah angka prima" #Variabel Angka prima yang menyimpan nilai string

if (Angka == 1 or Angka == 0): #Kondisi dimana jika Angka sama dengan 1 atau angka 1, maka
    prima = "ini bukan angka prima" #akan menghasilkan variabel prima yang menyimpan string

for i in range (2, Angka): #Perulangan untuk memeriksa apakah input dimulai antara angka 2 sampai angka yang diinput
    if (Angka % i == 0):   #Kondisi dimana jika angka input bisa dibagi dengan diri sendiri/habis, maka akan mencetak bilangan bukan prima
     AngkaPrima = "ini bukan angka prima"
print(Angka,AngkaPrima)   #Untuk mencetak variabel Angka dan AngkaPrima
print("\n----- Oleh L200220269 -----")