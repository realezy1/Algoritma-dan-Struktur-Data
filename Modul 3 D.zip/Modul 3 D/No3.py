class Node:
    def __init__(self, data, next=None):
        self.data = data
        self.next = next
    
class LinkedList:
    def __init__(self):
        self.head = None
    
    def printLinkedList(self):
        printval = self.head
        while printval is not None:
            print(printval.data)
            printval = printval.next
    
    def tambahAwal(self, Data):
        NodeBaru = Node(Data)
        NodeBaru.next = self.head
        self.head = NodeBaru
    
    def tambahAkhir(self, Data):
        NodeBaru = Node(Data)
        terakhir = self.head
        while(terakhir.next != None):
            terakhir = terakhir.next
        terakhir.next = NodeBaru

    def tambahTengah(self, tengah, newData):
        NewNode = Node(newData)
        tengah = self.head
        NewNode.next = tengah.next
        tengah.next = NewNode
    
    def hapusNode(self, Remove):
        HeadVal = self.head
        if (HeadVal is not None):
            if (HeadVal.data == Remove):
                self.head = HeadVal.next
                HeadVal = None
                return
        while (HeadVal is not None):
            if HeadVal.data == Remove:
                break
            prev = HeadVal
            HeadVal = HeadVal.next
        if (HeadVal == None):
            return
        prev.next = HeadVal.next
        HeadVal = None

    def cariNode(self, yang_dicari):
        cur = self.head
        while cur:
            if cur.data == yang_dicari:
                return True
            cur = cur.next
        return False
    
linklist = LinkedList()
linklist.tambahAwal(1)
linklist.tambahAwal(2)
linklist.tambahAkhir(3)
linklist.tambahTengah(4,5)
linklist.hapusNode(3)
linklist.cariNode(1)
linklist.printLinkedList()
print("\n---L200220269---")