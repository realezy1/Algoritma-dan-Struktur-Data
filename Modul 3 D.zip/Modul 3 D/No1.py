def is_consistent(matrix):
    if not all(isinstance(row, list) for row in matrix):
        return False
    num_cols = len(matrix[0])
    for row in matrix:
        if not isinstance(row, list) or len(row) != num_cols:
            return False
    return True

def matrix_size(matrix):
    if not is_consistent(matrix):
        return "Matrix tidak konsisten"
    num_rows = len(matrix)
    num_cols = len(matrix[0])
    return num_rows, num_cols

def matrix_addition(matrix1, matrix2):
    if matrix_size(matrix1) != matrix_size(matrix2):
        return "Ukuran matrix tidak sesuai"
    result = []
    for i in range(len(matrix1)):
        row = []
        for j in range(len(matrix1[0])):
            row.append(matrix1[i][j] + matrix2[i][j])
        result.append(row)
    return result

def matrix_multiplication(matrix1, matrix2):
    if matrix_size(matrix1) != matrix_size(matrix2):
        return "Ukuran matrix tidak sesuai"
    result = []
    for i in range(len(matrix1)):
        row = []
        for j in range(len(matrix2[0])):
            total = 0
            for k in range(len(matrix2)):
                total += matrix1[i][k] * matrix2[k][j]
            row.append(total)
        result.append(row)
    return result

def matrix_determinant(matrix):
    if not is_consistent(matrix):
        return "Matrix tidak konsisten"
    if len(matrix) != len(matrix[0]):
        return "Matrix bukan matriks persegi"
    if len(matrix) == 1:
        return matrix[0][0]
    if len(matrix) == 2:
        return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]
    det = 0
    for i in range(len(matrix)):
        minor = [row[:i] + row[i + 1:] for row in matrix[1:]]
        det += (-1) ** i * matrix[0][i] * matrix_determinant(minor)
    return det

matrix1 = [[7, 2, 4],
           [9, 3, 6],
           [8, 1, 9]]

matrix2 = [[5, 7, 7],
           [8, 4, 3],
           [3, 6, 3]]

print("Cek konsistensi M1:", is_consistent(matrix1))
print("Cek konsistensi M2:", is_consistent(matrix2))
print("Ukuran matrix:", matrix_size(matrix1))
print("Penjumlahan matrix:", matrix_addition(matrix1, matrix2))
print("Perkalian matrix:", matrix_multiplication(matrix1, matrix2))
print("Determinan matrix1:", matrix_determinant(matrix1))
print("\n---L200220269---")