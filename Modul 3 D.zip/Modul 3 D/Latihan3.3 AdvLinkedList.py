class DNode(object):
    def __init__(self,data) -> None:
        self.data = data
        self.next = None
        self.prev = None

    def kunjungi (head):
        curNode = head
        while curNode is not None:
            print(curNode.data)
            curNode = curNode.next

head = DNode(21)
a = DNode(17)
b = DNode(18)
tail = DNode(74)

head.next = a
a.next = b
a.prev = head
b.next = tail
b.prev = a
tail.prev = b

DNode.kunjungi(head)