B = [[0 for j in range(3)] for i in range(3)]
print(B)

#List Comprehension
#Membuat list kuadrat bilangan 0 sampai 6  
A = [x**2 for x in range(0,7)]
print(A)

#Membuat list yang berisi tuple pasangan bilangan dan kuadratnya dari 0 sampai 6
C = [(x,x**2) for x in range(7)]
print(C)

#Membuat list kuadrat bilangan genap antara 0 dan 15
D = [x**2 for x in range(15) if x % 2 == 0]
print(D)

#Membuat list sepanjang 5 elemen yang berisi bilangan 3
E = [3 for i in range(5)]
print(E)

#Membuat list sepanjang 3 elemen yang berisi list sepanjang 3 elemen angka 0
F = [[0 for j in range(3)] for i in range(3)]
print(F)

#Membuat matrix identitas 3x3
G = [[1 if j ==i else 0 for j in range(3)] for i in range(3)]
print(G)

#Membuat list yang berisi huruf vokal suatu string
d = "Yogyakarta dan Surakarta."
H = [x for x in d if x in "aiueoAIUEO"]
print(H)

#Membuat list bilangan prima dari 20 sampai 50
from tugas_5 import apakahPrima
I = [x for x in range(20,50) if apakahPrima(x)]
print(I)