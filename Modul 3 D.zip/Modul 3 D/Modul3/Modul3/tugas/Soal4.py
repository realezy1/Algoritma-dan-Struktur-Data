class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None
class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
    def kunjungi_awal(self):
        current = self.head
        while current:
            print(current.data, end=" ")
            current = current.next
        print()
    def kunjungi_akhir(self):
        current = self.tail
        while current:
            print(current.data, end=" ")
            current = current.prev
        print()
    def tambah_awal(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            self.tail = new_node
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node
    def tambah_akhir(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            new_node.prev = self.tail
            self.tail = new_node

dll = DoublyLinkedList()
dll.tambah_awal(3)
dll.tambah_awal(2)
dll.tambah_awal(1)
dll.tambah_akhir(4)
dll.tambah_akhir(5)
print("Mengunjungi dan mencetak data tiap simpul dari depan:")
dll.kunjungi_awal()
print("Mengunjungi dan mencetak data tiap simpul dari belakang:")
dll.kunjungi_akhir()
print('\n----- Oleh L200220141 -----\n')
