def cek_konsistensi(matrix):
    if not all(isinstance(row, list) for row in matrix):
        return False
    num_cols = len(matrix[0])
    for row in matrix:
        if not isinstance(row, list) or len(row) != num_cols:
            return False
    return True
def ukuran(matrix):
    if not cek_konsistensi(matrix):
        return "Matrix tidak konsisten"
    num_rows = len(matrix)
    num_cols = len(matrix[0])
    return num_rows, num_cols
def jumlah_matrix(matrix1, matrix2):
    if ukuran(matrix1) != ukuran(matrix2):
        return "Ukuran matrix tidak sesuai"
    result = []
    for i in range(len(matrix1)):
        row = []
        for j in range(len(matrix1[0])):
            row.append(matrix1[i][j] + matrix2[i][j])
        result.append(row)
    return result
def kali_matrix(matrix1, matrix2):
    if ukuran(matrix1) != ukuran(matrix2):
        return "Ukuran matrix tidak sesuai"
    result = []
    for i in range(len(matrix1)):
        row = []
        for j in range(len(matrix2[0])):
            total = 0
            for k in range(len(matrix2)):
                total += matrix1[i][k] * matrix2[k][j]
            row.append(total)
        result.append(row)
    return result
def determinan(matrix):
    if not cek_konsistensi(matrix):
        return "Matrix tidak konsisten"
    if len(matrix) != len(matrix[0]):
        return "Matrix bukan matriks persegi"
    if len(matrix) == 1:
        return matrix[0][0]
    if len(matrix) == 2:
        return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]
    det = 0
    for i in range(len(matrix)):
        minor = [row[:i] + row[i + 1:] for row in matrix[1:]]
        det += (-1) ** i * matrix[0][i] * determinan(minor)
    return det
matrix1 = [[1, 2, 3],
           [4, 5, 6],
           [7, 8, 9]]
matrix2 = [[9, 8, 7],
           [6, 5, 4],
           [3, 2, 1]]
print("Cek konsistensi M1:", cek_konsistensi(matrix1))
print("Cek konsistensi M2:", cek_konsistensi(matrix2))
print("Ukuran matrix:", ukuran(matrix1))
print("Penjumlahan matrix:", jumlah_matrix(matrix1, matrix2))
print("Perkalian matrix:", kali_matrix(matrix1, matrix2))
print("Determinan matrix1:", determinan(matrix1))