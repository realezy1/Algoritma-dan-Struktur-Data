class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
class LinkedList:
    def __init__(self):
        self.head = None
    def cari(self, yang_dicari):
        current = self.head
        while current:
            if current.data == yang_dicari:
                return True
            current = current.next
        return False
    def tambahDepan(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node
    def tambahAkhir(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            return
        last = self.head
        while last.next:
            last = last.next
        last.next = new_node
    def tambah(self, data, posisi):
        if posisi == 0:
            self.tambahDepan(data)
            return
        new_node = Node(data)
        current = self.head
        count = 0
        while current:
            if count == posisi - 1:
                new_node.next = current.next
                current.next = new_node
                return
            count += 1
            current = current.next
    def hapus(self, posisi):
        if posisi == 0:
            self.head = self.head.next
            return
        current = self.head
        prev = None
        count = 0
        while current and count != posisi:
            prev = current
            current = current.next
            count += 1
        if current is None:
            return
        prev.next = current.next
    def tampilkan(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")
        
linked_list = LinkedList()
linked_list.tambahDepan(3)
linked_list.tambahDepan(2)
linked_list.tambahDepan(1)
linked_list.tambahAkhir(4)
linked_list.tambahAkhir(5)
linked_list.tambah(10, 2)
linked_list.hapus(1)
print("Apakah Data 4 ditemukan? ", linked_list.cari(4))
linked_list.tampilkan()
print('\n----- Oleh L200220141 -----\n')
