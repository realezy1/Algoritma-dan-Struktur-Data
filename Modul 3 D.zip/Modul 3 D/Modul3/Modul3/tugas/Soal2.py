def buatNol(m, n=None):
    if n is None:
        n = m
    return [[0 for _ in range(n)] for _ in range(m)]
def buatIdentitas(m):
    return [[1 if i == j else 0 for j in range(m)] for i in range(m)]
print("Matrix nol 3x3:")
print(buatNol(3, 3))
print("\nMatrix nol 4x5:")
print(buatNol(4, 5))
print("\nMatrix identitas 4x4:")
print(buatIdentitas(4))
print('\n----- Oleh L200220141 -----\n')
