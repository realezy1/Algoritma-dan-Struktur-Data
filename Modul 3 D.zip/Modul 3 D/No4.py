class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None

class DoubLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
    
    def kunjungiDariDepan(self):
        cur = self.head
        while cur:
            print(cur.data, end=" ")
            cur = cur.next
        print()

    def kunjungiDariBelakang(self):
        cur = self.tail
        while cur:
            print(cur.data, end=" ")
            cur = cur.prev
        print()

    def tambahAwal(self, data):
        NewNode = Node(data)
        if not self.head:
            self.head = NewNode
            self.tail = NewNode
        else:
            NewNode.next = self.head
            self.head.prev = NewNode
            self.head = NewNode

    def tambahAkhir(self, data):
        NodeBaru = Node(data)
        if not self.head:
            self.head = NodeBaru
            self.tail = NodeBaru
        else:
            self.tail.next = NodeBaru
            NodeBaru.prev = self.tail
            self.tail = NodeBaru

dll = DoubLinkedList()
dll.tambahAwal(13)
dll.tambahAwal(1)
dll.tambahAwal(2)
dll.tambahAkhir(4)
dll.tambahAkhir(5)
print("Mengunjungi dan mencetak data tiap simpul dari depan:")
dll.kunjungiDariDepan()
print("Mengunjungi dan mencetak data tiap simpul dari belakang:")
dll.kunjungiDariBelakang()
print("\n---L200220269---")