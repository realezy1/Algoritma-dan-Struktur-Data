def buatNol(x, y=None):
    if y is None:
        y = x
    return [[0 for i in range(y)] for i in range(x)]
def buatIdentitas(a):
    return [[1 if i == j else 0 for j in range(a)] for i in range(a)]

print("Matrix nol 3x3:\n", buatNol(3, 3))
print("Matrix nol 4x5:\n", buatNol(4, 5))
print("Matrix identitas:\n", buatIdentitas(4))
print("\n---L200220269---")