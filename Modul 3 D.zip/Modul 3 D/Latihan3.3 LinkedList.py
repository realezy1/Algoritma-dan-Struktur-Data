class Node(object):
    """Sebuah simpul di linked list"""
    def __init__(self, data, next=None) -> None:
        self.data = data
        self.next = next
    
a = Node(11)
b = Node(52)
c = Node(18)

a.next = b
b.next = c

print(a.data)
print(a.next.data)
print(a.next.next.data)

def kunjungi (head):
    curNode = head
    while curNode is not None:
        print(curNode.data)
        curNode = curNode.next