def binarySearch26(kumpulanList,sasaran):
    #mencarinya mulai dari seluruh urutan list
    rendah = 0
    tinggi = len(kumpulanList) - 1
    
    #perulangan untuk memisahkan menjadi separuhnya
    #secara terus-menerus hingga target ditemukan
    while rendah <= tinggi:
        #untuk menemukan tengah dari sebuah urutan list
        tengah = (tinggi + rendah) // 2
        #memeriksa apakah di tengah terdapat sasarannya
        if kumpulanList[tengah] == sasaran:
            return True
        #memeriksa apakah target di sebelah kiri
        elif sasaran < kumpulanList[tengah]:
            tinggi = tengah - 1
        else:
        #memeriksa apakah target di sebelah kanan
            rendah = tengah + 1
    #jika list tidak bisa dipisahkan lagi maka target tidak ada
    return False

list = [2,3,5,7,8,9,13,15,17,18,20,21,23,25,26,29,32,35,36]
print("Apakah angka 26 ditemukan? jika iya maka True, jika tidak maka False,",binarySearch26(list,26))
print("\n---L200220269---")