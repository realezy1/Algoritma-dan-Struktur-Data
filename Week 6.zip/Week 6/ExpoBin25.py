def BinarySearch(kumpulan, nilai):
    # mulai dari seluruh urutan list
    awal = 0
    akhir = len(kumpulan) - 1
    index = -1
    #perulangan untuk memisahkan menjadi separuhnya
    #secara terus-menerus hingga target ditemukan
    while awal <= akhir and index == -1:
        #untuk menemukan tengah dari sebuah urutan list
        tengah = (awal + akhir) // 2
        if kumpulan[tengah] == nilai:
        #memeriksa apakah di tengah terdapat sasarannya
            index = tengah
        elif nilai < kumpulan[tengah]:
        #memeriksa apakah target di sebelah kiri
            akhir = tengah - 1
        else:
        #memeriksa apakah target di sebelah kanan
            awal = tengah + 1
    #jika list tidak bisa dipisahkan lagi maka target tidak ada
    return index


def expoSearch25(kumpulanList, sasaran):
    #memeriksa kumpulan list pada index 0, jika sama dengan sasaran
    #maka mengembalikan nilai 0
    if kumpulanList[0] == sasaran:
        return 0
    index = 1
    #perulangan untuk menemukan rentang dimana sasaran mungkin berada
    while index < len(kumpulanList) and kumpulanList[index] <= sasaran:
        index *= 2

    #fungsi BinarySearch di dalam expoSearch26 untuk mencari sasaran dalam bentuk nilai indeks
    return BinarySearch(kumpulanList[:min(index, len(kumpulanList))], sasaran) + (index // 2)

KumpulanList = [2,3,5,7,8,9,13,15,17,18,20,21,23,25,26,29,32,35,36]
sasaran = 25
cari = expoSearch25(KumpulanList,sasaran)
print(sasaran,"ditemukan di indeks:",cari)
print("\n---L200220269---")