import math
import random

def permainanTebakAngka(batas_bawah, batas_atas):
    print("Permainan tebak angka dan saya memiliki angka dari 1-100.")

    tebakanMaksimal = hitungMaksimalTebakan(batas_bawah, batas_atas)
    print(f"Anda memiliki kesempatan menebak sebanyak {tebakanMaksimal} kali.")
    
    angkaRandom = random.randint(batas_bawah, batas_atas)
    tebakan_ke = 1
    while tebakan_ke <= tebakanMaksimal:
        tebakan = int(input(f"Masukkan tebakan ke-{tebakan_ke}: "))
        if tebakan < angkaRandom:
            print("Angka terlalu kecil. Silahkan anda coba lagi!")
        elif tebakan > angkaRandom:
            print("Angka terlalu besar. Silahkan anda coba lagi!")
        else:
            print("Selamat kamu benar!")
            return  
        tebakan_ke += 1
    print(f"Kesempatan menebak anda habis. Angka yang benar adalah {angkaRandom}.")

def hitungMaksimalTebakan(rentang_bawah, rentang_atas):
    rentang = rentang_atas - rentang_bawah + 1
    return math.ceil(math.log2(rentang))

permainanTebakAngka(1, 100)
print("\n---L200220269---")