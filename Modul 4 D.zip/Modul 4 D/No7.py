def binSe(kumpulan, target):
    terendah = 0
    tertinggi = len(kumpulan) - 1
    ListKosong = []
    while terendah <= tertinggi:
        tengah = (tertinggi + terendah) // 2
        if kumpulan[tengah] == target:
            kiri = tengah
            while kiri >= 0 and kumpulan[kiri] == target:
                ListKosong.append(kiri)
                kiri -= 1
            kanan = tengah + 1
            while kanan < len(kumpulan) and kumpulan[kanan] == target:
                ListKosong.append(kanan)
                kanan += 1
            return ListKosong 
        elif target < kumpulan[tengah]:
            tertinggi = tengah - 1
        else:
            terendah = tengah + 1
    return ListKosong

List = [2, 3, 5, 6, 6, 6, 8, 9, 9, 10, 11, 12, 13, 13, 14]
target = 6
result = binSe(List,target)
print(result)
print("\n---L200220269---")