import LatOOP4

c0 = LatOOP4.MhsTIF('Ika',10,'Sukoharjo',240000)
c1 = LatOOP4.MhsTIF('Budi',51,'Sragen',230000)
c2 = LatOOP4.MhsTIF('Ahmad',2,'Surakarta',250000)
c3 = LatOOP4.MhsTIF('Chandra',18,'Surakarta',235000)
c4 = LatOOP4.MhsTIF('Eka',4,'Boyolali',240000)
c5 = LatOOP4.MhsTIF('Fandi',31,'Salatiga',250000)
c6 = LatOOP4.MhsTIF('Deni',13,'Klaten',245000)
c7 = LatOOP4.MhsTIF('Galuh',5,'Wonogiri',245000)
c8 = LatOOP4.MhsTIF('Janto',23,'Klaten',245000)
c9 = LatOOP4.MhsTIF('Hasan',64,'Karanganyar',270000)
c10 = LatOOP4.MhsTIF('Khalid',29,'Purwodadi',265000)

DaftarList = [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10]
ListMahasiswa = [mahasiswa for mahasiswa in DaftarList if mahasiswa.uangSaku < 250000]
for mahasiswa in ListMahasiswa:
    print(mahasiswa.nama, mahasiswa.uangSaku)
print("\n---L200220269---")