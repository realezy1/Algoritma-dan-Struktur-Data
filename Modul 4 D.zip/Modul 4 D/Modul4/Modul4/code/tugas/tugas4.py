import main
c0 = main.MhsTIF('Ika',10,'Sukoharjo',240000)
c1 = main.MhsTIF('Budi',51,'Sragen',230000)
c2 = main.MhsTIF('Ahmad',2,'Surakarta',250000)
c3 = main.MhsTIF('Chandra',18,'Surakarta',235000)
c4 = main.MhsTIF('Eka',4,'Boyolali',230000)
c5 = main.MhsTIF('Fandi',31,'Salatiga',250000)
c6 = main.MhsTIF('Deni',13,'Klaten',245000)
c7 = main.MhsTIF('Galuh',5,'Wonogiri',245000)
c8 = main.MhsTIF('Janto',23,'Klaten',245000)
c9 = main.MhsTIF('Hasan',64,'Karanganyar',270000)
c10 = main.MhsTIF('Khalid',29,'Purwodadi',265000)
Daftar = [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10]
listmahasiswa = []
for mahasiswa in Daftar:
    if mahasiswa.uangSaku < 250000:
        listmahasiswa.append(mahasiswa)
for mahasiswa in listmahasiswa:
    print(mahasiswa)
print('\n----- Oleh L200220141 -----\n')
