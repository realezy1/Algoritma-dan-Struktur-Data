def binSe(kumpulan, target):
    low = 0
    high = len(kumpulan) - 1
    while low <= high:
        mid = (high + low) // 2
        if kumpulan[mid] == target:
            return mid  
        elif target < kumpulan[mid]:
            high = mid - 1
        else:
            low = mid + 1   
    return False  
kumpulan = [1, 3, 5, 7, 9, 11, 13, 15, 17]
target = 11
hasil = binSe(kumpulan, target)
if hasil is not False:
    print(f"Elemen {target} ditemukan di indeks {hasil}")
else:
    print("Elemen tidak ditemukan.")
print('\n----- Oleh L200220141 -----\n')