class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
class LinkedList:
    def __init__(self):
        self.head = None
    def append(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        last_node = self.head
        while last_node.next:
            last_node = last_node.next
        last_node.next = new_node
    def search(self, item):
        current = self.head
        index = 0
        found_indexes = []
        while current:
            if current.data == item:
                found_indexes.append(index)
            current = current.next
            index += 1
        return found_indexes
    def display(self):
        current = self.head
        while current:
            print(current.data, end=" ")
            current = current.next
        print()
linked_list = LinkedList()
linked_list.append(2)
linked_list.append(3)
linked_list.append(5)
linked_list.append(6)
linked_list.append(6)
linked_list.append(6)
linked_list.append(8)
linked_list.append(9)
linked_list.append(9)
linked_list.append(10)
linked_list.append(11)
linked_list.append(12)
linked_list.append(13)
linked_list.append(13)
linked_list.append(14)
item_to_search = 6
indexes = linked_list.search(item_to_search)
print(f"Item {item_to_search} ditemukan di indeks: {indexes}")
print('\n----- Oleh L200220141 -----\n')