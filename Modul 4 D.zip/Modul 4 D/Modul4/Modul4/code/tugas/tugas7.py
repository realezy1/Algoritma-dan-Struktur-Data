def binSe(kumpulan, target):
    low = 0
    high = len(kumpulan) - 1
    found_indices = []
    while low <= high:
        mid = (high + low) // 2
        if kumpulan[mid] == target:
            left = mid
            while left >= 0 and kumpulan[left] == target:
                found_indices.append(left)
                left -= 1
            right = mid + 1
            while right < len(kumpulan) and kumpulan[right] == target:
                found_indices.append(right)
                right += 1
            return found_indices 
        elif target < kumpulan[mid]:
            high = mid - 1
        else:
            low = mid + 1
    return found_indices
kumpulan = [2, 3, 5, 6, 6, 6, 8, 9, 9, 10, 11, 12, 13, 13, 14]
target = 6
hasil = binSe(kumpulan, target)
if hasil:
    print(hasil)
else:
    print("Elemen tidak ditemukan.")
print('\n----- Oleh L200220141 -----\n')