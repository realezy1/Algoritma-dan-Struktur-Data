import math
import random
def permainan(rentang_bawah, rentang_atas):
    print('----- Oleh L200220141 -----')
    print("Permainan tebak angka.")
    print("Saya menyimpan sebuah angka bulat antara 1 sampai 100.")
    maks_tebakan = hitung_maks_tebakan(rentang_bawah, rentang_atas)
    print(f"Anda memiliki kesempatan menebak sebanyak {maks_tebakan} kali.")
    angka_rahasia = random.randint(rentang_bawah, rentang_atas)
    tebakan_ke = 1
    while tebakan_ke <= maks_tebakan:
        tebakan = int(input(f"Masukkan tebakan ke-{tebakan_ke}: "))
        if tebakan < angka_rahasia:
            print("Itu terlalu kecil. Coba lagi.")
        elif tebakan > angka_rahasia:
            print("Itu terlalu besar. Coba lagi.")
        else:
            print("Ya. Anda benar.")
            return  
        tebakan_ke += 1
    print(f"Maaf, kesempatan menebak anda habis. Angka yang benar adalah {angka_rahasia}.")
def hitung_maks_tebakan(rentang_bawah, rentang_atas):
    rentang = rentang_atas - rentang_bawah + 1
    return math.ceil(math.log2(rentang))

permainan(1, 1000)