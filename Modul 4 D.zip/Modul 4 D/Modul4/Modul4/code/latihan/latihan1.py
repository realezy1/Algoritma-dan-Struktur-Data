import LatOOP4
def linearSearch(arrayTempatYangDicari, target):
    if target in arrayTempatYangDicari:
        print("Target terdapat di array itu")
    else:
        print("targetnya tidak terdapat diarray itu")
        
A = [10,51,2,18,4,31,13,5,23,64,29]

def cariLurus(wadah,target):
    n = len(wadah)
    for i in range(n):
        if wadah[i] == target:
            return True
    return False

print(cariLurus(A, 31))
print(cariLurus(A, 8))

c0 = LatOOP4.MhsTIF('Ika',10,'Sukoharjo',240000)
c1 = LatOOP4.MhsTIF('Budi',51,'Sragen',230000)
c2 = LatOOP4.MhsTIF('Ahmad',2,'Surakarta',250000)
c3 = LatOOP4.MhsTIF('Chandra',18,'Surakarta',235000)
c4 = LatOOP4.MhsTIF('Eka',4,'Boyolali',240000)
c5 = LatOOP4.MhsTIF('Fandi',31,'Salatiga',250000)
c6 = LatOOP4.MhsTIF('Deni',13,'Klaten',245000)
c7 = LatOOP4.MhsTIF('Galuh',5,'Wonogiri',245000)
c8 = LatOOP4.MhsTIF('Janto',23,'Klaten',245000)
c9 = LatOOP4.MhsTIF('Hasan',64,'Karanganyar',270000)
c10 = LatOOP4.MhsTIF('Khalid',29,'Purwodadi',265000)

Daftar = [c0, c1, c2, c3, c4, c5, c6, c7, c8, c9, c10]

target = 'Klaten'
for i in Daftar:
    if i.kota == target:
        print(i.nama + ' tinggal di ' + target)
        
def cariTerkecil(kumpulan):
    n = len(kumpulan)
    terkecil = kumpulan[0]
    for i in range(1,n):
        if kumpulan[i] < terkecil:
            terkecil = kumpulan[i]
    return terkecil

