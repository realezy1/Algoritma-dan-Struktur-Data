class Manusia(object):
    """Class 'Manusia' dengan inisiasi 'nama'"""
    keadaan = 'lapar'
    def __init__(self, nama):
        self.nama = nama
    def makan(self, s):
        print('Saya baru saja makan',s)
        self.keadaan = 'kenyang'
    def olahraga(self, s):
        print('Saya baru saja latihan',s)
        self.keadaan = 'lapar'
    def mengalikanDenganDua(self, n):
        return n*2

class Mahasiswa(Manusia):
    """Class Mahasiswa yang dibangun dari class Manusia."""
    listKuliah = []
    def __init__(self,nama,NIM,kota,us):
        """Metode inisiasi ini menutupi metode inisiasi di class Manusia."""
        self.nama = nama
        self.NIM = NIM
        self.kota = kota
        self.uangSaku = us

    def __str__(self):
        s = self.nama + ', NIM ' + str(self.NIM) \
            + '. Tinggal di ' + self.kota \
            + '. Uang saku Rp ' + str(self.uangSaku) \
            + ' tiap bulannya.'
        return s

    def ambilNama(self):
        return self.nama

    def ambilNIM(self):
        return self.NIM

    def ambilUangSaku(self):
        return self.uangSaku
    
    def ambilKotaTinggal(self):
        return self.kota
    
    def perbaruiKotaTinggal(self, kotaBaru):
        self.kota = kotaBaru
    
    def tambahUangSaku(self, tambahUang):
        self.uangSaku = self.uangSaku + tambahUang
    
    def makan(self,s):
        """Metode ini menutupi metode 'makan'-nya class Manusia.
        Mahasiswa kalau makan sambil belajar."""
        print("Saya baru saja makan",s,"sambil")
        self.keadaan = 'kenyang'
        
    def ambilKuliah(self, kuliah):
        self.listKuliah.append(kuliah)
        
    def hapusKuliah(self, kuliah):
        self.listKuliah.remove(kuliah)
    
class MhsTIF(Mahasiswa):
    """Class MhsTIF yang dibangun dari class Mahasiswa."""
    def katakanPy(self):
        print('Python is cool.')